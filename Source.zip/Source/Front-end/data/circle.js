export const CIRCLES = [
    {
      id: 1,
      name: 'Circle 1'
    },
    {
      id: 2,
      name: 'Circle 2'
    },
    {
      id: 3,
      name: 'Circle 3'
    },
    {
      id: 4,
      name: 'Circle 4'
    }
  ];